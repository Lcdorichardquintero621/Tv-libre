# TV Libre – Móvil
App para teléfonos y tabletas Android (applicationId: com.tvlibre.movil).
Proyecto independiente: no comparte código con la versión de TV.
