package com.tvlibre.app

import java.util.Locale

/** Nombres de país (con bandera) e idioma para mostrar en cada fila. */
object Info {
    private fun fix(cc: String) = if (cc.equals("uk", true)) "gb" else cc

    fun countryName(cc: String): String {
        val c = fix(cc)
        val n = Locale("", c.uppercase()).getDisplayCountry(Locale("es"))
        return if (n.isBlank() || n.equals(c, true)) c.uppercase() else n
    }

    fun flag(cc: String): String {
        val c = fix(cc).uppercase()
        if (c.length != 2 || !c.all { it in 'A'..'Z' }) return ""
        return String(Character.toChars(0x1F1E6 + (c[0] - 'A'))) +
            String(Character.toChars(0x1F1E6 + (c[1] - 'A')))
    }

    private val langs = mapOf(
        "spa" to "Español", "es" to "Español", "spanish" to "Español", "español" to "Español",
        "eng" to "Inglés", "en" to "Inglés", "english" to "Inglés",
        "fre" to "Francés", "fra" to "Francés", "fr" to "Francés", "french" to "Francés",
        "ger" to "Alemán", "deu" to "Alemán", "de" to "Alemán", "german" to "Alemán",
        "ita" to "Italiano", "it" to "Italiano", "italian" to "Italiano",
        "por" to "Portugués", "pt" to "Portugués", "portuguese" to "Portugués",
        "rus" to "Ruso", "ru" to "Ruso", "russian" to "Ruso",
        "jpn" to "Japonés", "ja" to "Japonés", "japanese" to "Japonés",
        "chi" to "Chino", "zho" to "Chino", "zh" to "Chino", "chinese" to "Chino",
        "ara" to "Árabe", "ar" to "Árabe", "arabic" to "Árabe",
        "kor" to "Coreano", "ko" to "Coreano", "korean" to "Coreano"
    )

    fun langName(raw: String): String {
        val first = raw.split(';', ',', '/').firstOrNull()?.trim().orEmpty()
        if (first.isEmpty()) return ""
        return langs[first.lowercase()]
            ?: if (first.length <= 3) first.uppercase() else first.replaceFirstChar { it.uppercase() }
    }

    private val es = setOf("pe", "mx", "es", "ar", "co", "cl", "ve", "ec", "bo", "uy", "py",
        "cr", "pa", "gt", "hn", "ni", "sv", "do", "cu", "pr")
    private val en = setOf("us", "gb", "uk", "au", "nz", "ie")

    /** Idioma principal del país (se usa solo si la lista no indica el idioma). */
    fun mainLanguageOf(cc: String): String = when {
        cc in es -> "Español"
        cc in en -> "Inglés"
        cc == "br" || cc == "pt" -> "Portugués"
        cc == "fr" -> "Francés"
        cc == "de" || cc == "at" -> "Alemán"
        cc == "it" -> "Italiano"
        cc == "ru" -> "Ruso"
        cc == "jp" -> "Japonés"
        cc == "kr" -> "Coreano"
        else -> ""
    }

    private val groups = mapOf(
        "religious" to "Religioso", "business" to "Negocios", "general" to "General",
        "family" to "Familiar", "news" to "Noticias", "sports" to "Deportes", "music" to "Música",
        "kids" to "Infantil", "movies" to "Películas", "entertainment" to "Entretenimiento",
        "documentary" to "Documentales", "culture" to "Cultura", "education" to "Educación",
        "comedy" to "Comedia", "animation" to "Animación", "series" to "Series",
        "lifestyle" to "Estilo de vida", "outdoor" to "Aire libre", "travel" to "Viajes",
        "science" to "Ciencia", "cooking" to "Cocina", "weather" to "Clima", "shop" to "Compras",
        "relax" to "Relax", "classic" to "Clásicos", "legislative" to "Legislativo",
        "public" to "Público", "auto" to "Autos", "interactive" to "Interactivo",
        "xxx" to "Adulto", "undefined" to "Otros"
    )

    /** Traduce el grupo de la lista (en inglés) para mostrarlo en español. */
    fun groupName(raw: String): String =
        raw.split(';').map { it.trim() }.filter { it.isNotEmpty() }
            .joinToString(" · ") { groups[it.lowercase()] ?: it }
}
