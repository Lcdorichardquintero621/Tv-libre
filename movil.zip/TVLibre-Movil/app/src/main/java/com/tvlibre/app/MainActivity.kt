package com.tvlibre.app

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.PopupWindow
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.card.MaterialCardView
import com.google.android.material.checkbox.MaterialCheckBox
import com.google.android.material.color.MaterialColors

class MainActivity : AppCompatActivity() {

    private val FAV = "★ Favoritos"
    private val DEFAULT = "🌎 Todos en español"
    private val CUSTOM = "Mi lista M3U"
    private val base = "https://iptv-org.github.io/iptv"
    private val sources = LinkedHashMap<String, String>()
    private val countryLabels = LinkedHashSet<String>()
    private val movieLabels = LinkedHashSet<String>()
    private val listLabels = LinkedHashMap<String, String>() // etiqueta -> nombre de lista (Favoritos y 📁)
    private val selectedCats = LinkedHashSet<String>()      // categorías marcadas en el filtro
    private var currentLabel = ""
    private var labelChannels = DEFAULT   // última selección en modo Canales
    private var labelMovies = ""          // última selección en modo Películas
    private var movieMode = false
    private var all: List<Channel> = emptyList()
    private var requestId = 0
    private var onlyOk = true // "Solo canales que funcionan" encendido al abrir la app
    private var refreshPending = false
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var prefs: SharedPreferences
    private lateinit var store: ListStore
    private lateinit var modeToggle: MaterialButtonToggleGroup
    private lateinit var dropdowns: LinearLayout
    private lateinit var chipLists: MaterialButton
    private lateinit var chipCountry: MaterialButton
    private lateinit var chipCats: MaterialButton
    private lateinit var chipMovies: MaterialButton
    private lateinit var search: EditText
    private lateinit var progress: ProgressBar
    private lateinit var empty: TextView
    private lateinit var countText: TextView
    private lateinit var sectionTitle: TextView
    private lateinit var recycler: RecyclerView
    private lateinit var adapter: ChannelAdapter
    private lateinit var movieAdapter: MovieAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        if (Tv.isTv(this)) {
            // Márgenes seguros para pantallas de TV
            findViewById<View>(R.id.root).setPadding(Tv.dp(this, 32), Tv.dp(this, 16), Tv.dp(this, 32), Tv.dp(this, 16))
        }
        prefs = getSharedPreferences("tv", Context.MODE_PRIVATE)
        store = ListStore(prefs, FAV)

        // TV en línea gratis (listas públicas iptv-org)
        sources[DEFAULT] = "$base/languages/spa.m3u"
        // Un país de habla hispana por opción (más España y EE. UU.)
        for (cc in listOf("ve", "ec", "pe", "co", "mx", "ar", "cl", "bo", "py", "uy",
            "cr", "pa", "gt", "hn", "ni", "sv", "do", "cu", "pr", "es", "us")) {
            val label = Info.flag(cc) + " " + Info.countryName(cc)
            sources[label] = "$base/countries/$cc.m3u"
            countryLabels.add(label)
        }
        // Películas y series gratis y legales (Internet Archive, dominio público)
        sources["🎬 Películas clásicas"] = "ia:collection:feature_films AND mediatype:movies"
        sources["🎬 Películas en español"] = "ia:collection:feature_films AND mediatype:movies AND (language:Spanish OR language:spa)"
        sources["🎬 Ciencia ficción y terror"] = "ia:collection:SciFi_Horror AND mediatype:movies"
        sources["🎬 Cine mudo"] = "ia:collection:silent_films AND mediatype:movies"
        sources["📺 TV clásica"] = "ia:collection:classic_tv AND mediatype:movies"
        for (k in sources.keys) if (k.startsWith("🎬") || k.startsWith("📺")) movieLabels.add(k)
        labelMovies = movieLabels.first()
        prefs.getString("custom", null)?.let { sources[CUSTOM] = it }

        modeToggle = findViewById(R.id.modeToggle)
        dropdowns = findViewById(R.id.dropdowns)
        search = findViewById(R.id.search)
        progress = findViewById(R.id.progress)
        empty = findViewById(R.id.empty)
        countText = findViewById(R.id.count)
        sectionTitle = findViewById(R.id.sectionTitle)
        recycler = findViewById(R.id.recycler)

        adapter = ChannelAdapter(
            onClick = { open(it) },
            onFav = { toggleFav(it) },
            onMenu = { showListsDialog(it) },
            onGuide = { Guide.show(this, it) },
            isFav = { store.contains(FAV, it) }
        )
        movieAdapter = MovieAdapter(
            onClick = { open(it) },
            onFav = { toggleFav(it) },
            onMenu = { showListsDialog(it) },
            isFav = { store.contains(FAV, it) }
        )

        // Modo Canales: Canales ▾ · País ▾ · Categorías ▾    Modo Películas: Colección ▾
        chipLists = addDropdown(1.1f) { showSourceMenu(it, channelEntries()) }
        chipCountry = addDropdown(0.9f) { showSourceMenu(it, countryLabels.toList()) }
        chipCats = addDropdown(1.3f) { showCategories(it) }
        chipMovies = addDropdown(1f) { showSourceMenu(it, movieEntries()) }

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { applyFilter() }
        })
        findViewById<View>(R.id.btnMenu).setOnClickListener { showMenu(it) }

        modeToggle.check(R.id.modeChannels)
        modeToggle.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (isChecked) switchMode(checkedId == R.id.modeMovies)
        }
        applyMode()
        setupSources(null)
    }

    // ---------- Modo: Canales (lista) o Películas (cuadrícula con carátulas) ----------

    private fun switchMode(movies: Boolean) {
        if (movies == movieMode) return
        rememberLabel()
        movieMode = movies
        applyMode()
        val wanted = if (movies) labelMovies else labelChannels
        currentLabel = ""
        all = emptyList()
        submitList(emptyList())
        setupSources(wanted)
    }

    private fun applyMode() {
        recycler.layoutManager = when {
            movieMode -> GridLayoutManager(this, movieSpan())
            Tv.isTv(this) -> GridLayoutManager(this, 2)
            else -> LinearLayoutManager(this)
        }
        recycler.adapter = if (movieMode) movieAdapter else adapter
        val ch = if (movieMode) View.GONE else View.VISIBLE
        chipLists.visibility = ch
        chipCountry.visibility = ch
        chipCats.visibility = ch
        chipMovies.visibility = if (movieMode) View.VISIBLE else View.GONE
        search.hint = if (movieMode) "🔍  Buscar película por título o año" else "🔍  Buscar canal, país o idioma"
    }

    private fun movieSpan(): Int {
        if (Tv.isTv(this)) return 4
        return (resources.configuration.screenWidthDp / 170).coerceIn(2, 6)
    }

    private fun submitList(list: List<Channel>) {
        if (movieMode) movieAdapter.submit(list) else adapter.submit(list)
    }

    private fun rememberLabel() {
        if (currentLabel.isEmpty()) return
        if (movieMode) labelMovies = currentLabel else labelChannels = currentLabel
    }

    // ---------- Menús desplegables ----------

    private fun channelEntries(): List<String> {
        val out = ArrayList<String>()
        out.add(DEFAULT)
        if (CUSTOM in sources) out.add(CUSTOM)
        out.addAll(listLabels.keys)
        return out
    }

    private fun movieEntries(): List<String> = movieLabels.toList() + listLabels.keys

    private fun validLabels(): Set<String> =
        if (movieMode) movieEntries().toSet() else (channelEntries() + countryLabels).toSet()

    private fun addDropdown(weight: Float, onClick: (View) -> Unit): MaterialButton {
        val b = layoutInflater.inflate(R.layout.btn_dropdown, dropdowns, false) as MaterialButton
        val lp = b.layoutParams as LinearLayout.LayoutParams
        lp.weight = weight
        lp.marginStart = Tv.dp(this, 4)
        lp.marginEnd = Tv.dp(this, 4)
        b.setOnClickListener { onClick(it) }
        dropdowns.addView(b)
        return b
    }

    /** El botón resaltado indica en cuál menú está lo que se está viendo. */
    private fun setDropdown(b: MaterialButton, text: String, active: Boolean) {
        b.text = "$text ▾"
        val bg = if (active) MaterialColors.getColor(b, com.google.android.material.R.attr.colorSecondaryContainer)
                 else Color.TRANSPARENT
        val fg = MaterialColors.getColor(
            b,
            if (active) com.google.android.material.R.attr.colorOnSecondaryContainer
            else com.google.android.material.R.attr.colorOnSurface
        )
        b.backgroundTintList = ColorStateList.valueOf(bg)
        b.setTextColor(fg)
    }

    private fun refreshDropdowns() {
        val inCountry = currentLabel in countryLabels
        setDropdown(chipLists, "📺 Canales", !inCountry)
        setDropdown(chipCountry, if (inCountry) currentLabel else "🌎 País", inCountry)
        val n = selectedCats.size
        val catText = if (n == 0) "🏷 Categorías" else "🏷 $n categoría" + (if (n > 1) "s" else "")
        setDropdown(chipCats, catText, n > 0)
        setDropdown(chipMovies, "🎞 Colección", true)
        sectionTitle.text = currentLabel
    }

    /** Menú desplegable de una sola opción (canales, país o colección de películas). */
    private fun showSourceMenu(anchor: View, entries: List<String>) {
        if (entries.isEmpty()) return
        PopupMenu(this, anchor).apply {
            entries.forEachIndexed { i, label ->
                menu.add(0, i, i, (if (label == currentLabel) "● " else "") + label)
            }
            setOnMenuItemClickListener { item ->
                selectSource(entries[item.itemId])
                true
            }
            show()
        }
    }

    private fun selectSource(label: String) {
        if (label != currentLabel) {
            currentLabel = label
            load(label)
        }
        rememberLabel()
        refreshDropdowns()
    }

    /** Menú desplegable de categorías: se pueden marcar varias y se aplican al instante. */
    private fun showCategories(anchor: View) {
        val pad = Tv.dp(this, 8)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        val boxes = ArrayList<MaterialCheckBox>()
        var bulk = false
        val clear = TextView(this).apply {
            text = "✕ Quitar filtros"
            textSize = 14f
            alpha = 0.8f
            isFocusable = true
            isClickable = true
            setPadding(pad * 2, pad, pad * 2, pad)
        }
        clear.setOnClickListener {
            bulk = true
            selectedCats.clear()
            boxes.forEach { it.isChecked = false }
            bulk = false
            refreshDropdowns()
            applyFilter()
        }
        box.addView(clear)
        for (name in Categories.names) {
            val cb = MaterialCheckBox(this).apply {
                text = name
                textSize = 15f
                minHeight = Tv.dp(this@MainActivity, 48)
                isChecked = name in selectedCats
            }
            cb.setOnCheckedChangeListener { _, checked ->
                if (bulk) return@setOnCheckedChangeListener
                if (checked) selectedCats.add(name) else selectedCats.remove(name)
                refreshDropdowns()
                applyFilter()
            }
            boxes.add(cb)
            box.addView(cb)
        }
        val screen = resources.displayMetrics
        val w = minOf((screen.widthPixels * 0.8).toInt(), Tv.dp(this, 320))
        box.measure(
            View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val h = minOf(box.measuredHeight, (screen.heightPixels * 0.6).toInt())
        val card = MaterialCardView(this).apply {
            radius = Tv.dp(this@MainActivity, 16).toFloat()
            cardElevation = Tv.dp(this@MainActivity, 6).toFloat()
            addView(ScrollView(this@MainActivity).apply { addView(box) })
        }
        PopupWindow(card, w, h, true).apply {
            isOutsideTouchable = true
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            elevation = Tv.dp(this@MainActivity, 8).toFloat()
            showAsDropDown(anchor)
        }
    }

    private fun defaultLabel() = if (movieMode) movieLabels.first() else DEFAULT

    private fun setupSources(select: String?) {
        listLabels.clear()
        for (n in store.names()) {
            listLabels[if (n == FAV) FAV else "📁 $n"] = n
        }
        val wanted = select ?: currentLabel
        val target = if (wanted in validLabels()) wanted else defaultLabel()
        if (target != currentLabel) {
            currentLabel = target
            load(target)
        }
        rememberLabel()
        refreshDropdowns()
    }

    /** Favoritos y listas guardan canales y películas juntos: cada modo muestra lo suyo. */
    private fun listItems(name: String): List<Channel> =
        store.get(name).filter { it.url.startsWith("ia://") == movieMode }

    private fun load(label: String) {
        val id = ++requestId
        val listName = listLabels[label]
        if (listName != null) {
            progress.visibility = View.GONE
            all = listItems(listName)
            applyFilter()
            return
        }
        val url = sources[label] ?: return
        val defaultLang = if (label == DEFAULT) "Español" else ""
        progress.visibility = View.VISIBLE
        Thread {
            try {
                val list = if (url.startsWith("ia:")) Net.searchArchive(url.removePrefix("ia:"))
                           else M3uParser.parse(Net.httpGet(url), defaultLang)
                runOnUiThread {
                    if (id != requestId) return@runOnUiThread
                    progress.visibility = View.GONE
                    all = list
                    applyFilter()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (id != requestId) return@runOnUiThread
                    progress.visibility = View.GONE
                    all = emptyList()
                    applyFilter()
                    Toast.makeText(this, "No se pudo cargar la lista", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun isOk(ch: Channel) = ch.url.startsWith("ia://") || StatusChecker.status(ch.url) == 1

    private fun applyFilter() {
        val q = search.text.toString().trim().lowercase()
        var list: List<Channel> = if (movieMode) all else Categories.apply(all, selectedCats)
        if (q.isNotEmpty()) {
            list = list.filter {
                it.name.lowercase().contains(q) || it.group.lowercase().contains(q) ||
                    Info.countryName(it.country).lowercase().contains(q) || it.lang.lowercase().contains(q)
            }
        }
        var pending = 0
        val verify = onlyOk && !movieMode
        if (verify) {
            // Se comprueban en segundo plano solo los canales que se están mostrando
            for (ch in list) {
                if (!ch.url.startsWith("ia://")) StatusChecker.request(ch) { runOnUiThread { scheduleRefresh() } }
            }
            pending = list.count { !it.url.startsWith("ia://") && StatusChecker.status(it.url) <= 0 }
            list = list.filter { isOk(it) }
        }
        submitList(list)
        countText.text = when {
            movieMode -> "${list.size} películas"
            verify -> "${list.size} funcionan" + (if (pending > 0) " · verificando $pending…" else "")
            else -> "${list.size} canales"
        }
        empty.text = when {
            verify && pending > 0 -> "Verificando canales… irán apareciendo los que funcionan"
            !movieMode && selectedCats.isNotEmpty() -> "Ningún canal coincide con las categorías elegidas"
            else -> "Nada por aquí todavía"
        }
        empty.visibility = if (list.isEmpty() && progress.visibility != View.VISIBLE) View.VISIBLE else View.GONE
    }

    private fun scheduleRefresh() {
        if (refreshPending) return
        refreshPending = true
        ui.postDelayed({
            refreshPending = false
            applyFilter()
        }, 700)
    }

    private fun refreshView() {
        val ln = listLabels[currentLabel]
        if (ln != null) {
            all = listItems(ln)
            applyFilter()
        } else if (movieMode) {
            movieAdapter.notifyDataSetChanged()
        } else {
            adapter.notifyDataSetChanged()
        }
    }

    // ---------- Favoritos y listas personalizadas ----------

    private fun toggleFav(ch: Channel) {
        val msg: String
        if (store.contains(FAV, ch)) {
            store.remove(FAV, ch); msg = "Quitado de $FAV"
        } else {
            store.add(FAV, ch); msg = "Agregado a $FAV"
        }
        store.save()
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        refreshView()
    }

    private fun showListsDialog(ch: Channel) {
        val names = store.names().toTypedArray()
        val checked = BooleanArray(names.size) { store.contains(names[it], ch) }
        fun applyChecks() {
            names.forEachIndexed { i, n -> if (checked[i]) store.add(n, ch) else store.remove(n, ch) }
            store.save()
            refreshView()
        }
        AlertDialog.Builder(this)
            .setTitle(ch.name)
            .setMultiChoiceItems(names, checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("Guardar") { _, _ -> applyChecks() }
            .setNeutralButton("Nueva lista") { _, _ ->
                applyChecks()
                askNewList { showListsDialog(ch) }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun askNewList(onDone: (String) -> Unit) {
        val input = EditText(this).apply { hint = "Nombre de la lista" }
        AlertDialog.Builder(this)
            .setTitle("Nueva lista")
            .setView(input)
            .setPositiveButton("Crear") { _, _ ->
                val n = input.text.toString().trim()
                if (n.isEmpty() || store.names().contains(n) || n == FAV) {
                    Toast.makeText(this, "Nombre no válido o ya existe", Toast.LENGTH_SHORT).show()
                } else {
                    store.create(n)
                    store.save()
                    setupSources(null)
                    onDone(n)
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showMenu(anchor: View) {
        PopupMenu(this, anchor).apply {
            if (!movieMode) {
                menu.add(0, 4, 0, "Solo canales que funcionan").apply {
                    isCheckable = true
                    isChecked = onlyOk
                }
            }
            menu.add(0, 1, 1, "Nueva lista")
            menu.add(0, 2, 2, "Eliminar lista actual")
            if (!movieMode) menu.add(0, 3, 3, "Agregar lista M3U (URL)")
            setOnMenuItemClickListener {
                when (it.itemId) {
                    1 -> askNewList { n -> setupSources("📁 $n") }
                    2 -> deleteCurrentList()
                    3 -> askCustom()
                    4 -> { onlyOk = !onlyOk; applyFilter() }
                }
                true
            }
            show()
        }
    }

    private fun deleteCurrentList() {
        val ln = listLabels[currentLabel]
        if (ln == null || ln == FAV) {
            Toast.makeText(this, "Elige primero una de tus listas (📁)", Toast.LENGTH_LONG).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Eliminar \"$ln\"")
            .setMessage("Se borrará la lista y su contenido guardado.")
            .setPositiveButton("Eliminar") { _, _ ->
                store.delete(ln)
                store.save()
                setupSources(FAV)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun askCustom() {
        val input = EditText(this).apply {
            hint = "https://...lista.m3u"
            setText(prefs.getString("custom", ""))
        }
        AlertDialog.Builder(this)
            .setTitle("URL de lista M3U")
            .setView(input)
            .setPositiveButton("Guardar") { _, _ ->
                val u = input.text.toString().trim()
                if (u.startsWith("http")) {
                    prefs.edit().putString("custom", u).apply()
                    sources[CUSTOM] = u
                    currentLabel = ""
                    setupSources(CUSTOM)
                } else {
                    Toast.makeText(this, "URL no válida", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ---------- Reproducción ----------

    private fun open(ch: Channel) {
        val list = if (movieMode) movieAdapter.current() else adapter.current()
        Zap.items = list
        Zap.index = list.indexOfFirst { it.url == ch.url }.coerceAtLeast(0)
        Zap.label = currentLabel
        startActivity(Intent(this, PlayerActivity::class.java))
    }

    // ---------- Adaptador: miniatura, país, idioma y estado ----------

    class ChannelAdapter(
        private val onClick: (Channel) -> Unit,
        private val onFav: (Channel) -> Unit,
        private val onMenu: (Channel) -> Unit,
        private val onGuide: (Channel) -> Unit,
        private val isFav: (Channel) -> Boolean
    ) : RecyclerView.Adapter<ChannelAdapter.VH>() {
        private var items: List<Channel> = emptyList()
        private val main = Handler(Looper.getMainLooper())

        fun submit(list: List<Channel>) { items = list; notifyDataSetChanged() }

        fun current(): List<Channel> = items

        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val thumb: ImageView = v.findViewById(R.id.thumb)
            val name: TextView = v.findViewById(R.id.name)
            val info: TextView = v.findViewById(R.id.info)
            val group: TextView = v.findViewById(R.id.group)
            val status: TextView = v.findViewById(R.id.status)
            val star: TextView = v.findViewById(R.id.star)
            val guide: TextView = v.findViewById(R.id.guide)
            val menu: TextView = v.findViewById(R.id.menu)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_channel, parent, false))

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: VH, position: Int) {
            val ch = items[position]
            h.name.text = ch.name
            h.group.text = Info.groupName(ch.group)

            val parts = ArrayList<String>()
            if (ch.country.isNotEmpty()) {
                parts.add((Info.flag(ch.country) + " " + Info.countryName(ch.country)).trim())
            }
            if (ch.lang.isNotEmpty()) parts.add(ch.lang)
            h.info.text = parts.joinToString(" · ")
            h.info.visibility = if (parts.isEmpty()) View.GONE else View.VISIBLE

            if (ch.logo.isEmpty()) {
                Glide.with(h.thumb).clear(h.thumb)
                h.thumb.setImageResource(R.drawable.ic_placeholder)
            } else {
                Glide.with(h.thumb).load(ch.logo)
                    .placeholder(R.drawable.ic_placeholder)
                    .error(R.drawable.ic_placeholder)
                    .into(h.thumb)
            }

            bindStatus(h, ch)
            h.star.text = if (isFav(ch)) "★" else "☆"
            h.star.setOnClickListener { onFav(ch) }
            h.guide.setOnClickListener { onGuide(ch) }
            h.menu.setOnClickListener { onMenu(ch) }
            h.itemView.setOnClickListener { onClick(ch) }
            h.itemView.setOnLongClickListener { onMenu(ch); true }
            (h.itemView as? MaterialCardView)?.let { card ->
                val w = (3 * card.resources.displayMetrics.density).toInt()
                card.strokeColor = 0xFFFFC107.toInt()
                card.strokeWidth = if (card.hasFocus()) w else 0
                card.setOnFocusChangeListener { _, focused -> card.strokeWidth = if (focused) w else 0 }
            }
        }

        override fun onBindViewHolder(h: VH, position: Int, payloads: MutableList<Any>) {
            if (payloads.isNotEmpty()) bindStatus(h, items[position])
            else super.onBindViewHolder(h, position, payloads)
        }

        private fun bindStatus(h: VH, ch: Channel) {
            var st = StatusChecker.status(ch.url)
            if (st == -1) {
                StatusChecker.request(ch) { notifyUrl(ch.url) }
                st = 0
            }
            when (st) {
                1 -> { h.status.text = "✓"; h.status.setBackgroundResource(R.drawable.bg_ok) }
                2 -> { h.status.text = "✕"; h.status.setBackgroundResource(R.drawable.bg_fail) }
                else -> { h.status.text = "…"; h.status.setBackgroundResource(R.drawable.bg_wait) }
            }
        }

        private fun notifyUrl(url: String) {
            main.post {
                val i = items.indexOfFirst { it.url == url }
                if (i >= 0) notifyItemChanged(i, "status")
            }
        }
    }
}
