package com.tvlibre.app

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.PopupWindow
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.material.card.MaterialCardView
import com.google.android.material.chip.Chip
import com.google.android.material.checkbox.MaterialCheckBox
import com.google.android.material.chip.ChipGroup

class MainActivity : AppCompatActivity() {

    private val FAV = "★ Favoritos"
    private val DEFAULT = "🌎 Todos en español"
    private val base = "https://iptv-org.github.io/iptv"
    private val sources = LinkedHashMap<String, String>()
    private val countryLabels = LinkedHashSet<String>()
    private val listLabels = LinkedHashMap<String, String>() // etiqueta -> nombre de lista
    private val listEntries = ArrayList<String>()   // opciones del menú "Canales"
    private val movieLabels = LinkedHashSet<String>() // opciones del menú "Películas"
    private val selectedCats = LinkedHashSet<String>() // categorías marcadas en el filtro
    private var currentLabel = ""
    private var all: List<Channel> = emptyList()
    private var requestId = 0
    private var onlyOk = true // "Solo funcionan" encendido al abrir la app
    private var refreshPending = false
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var prefs: SharedPreferences
    private lateinit var store: ListStore
    private lateinit var dropdowns: ChipGroup
    private lateinit var chipLists: Chip
    private lateinit var chipCountry: Chip
    private lateinit var chipMovies: Chip
    private lateinit var chipCats: Chip
    private lateinit var search: EditText
    private lateinit var progress: ProgressBar
    private lateinit var empty: TextView
    private lateinit var countText: TextView
    private lateinit var chipOk: Chip
    private lateinit var adapter: ChannelAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        if (Tv.isTv(this)) {
            // Márgenes seguros para pantallas de TV
            findViewById<View>(R.id.root).setPadding(Tv.dp(this, 32), Tv.dp(this, 16), Tv.dp(this, 32), Tv.dp(this, 16))
        }
        prefs = getSharedPreferences("tv", Context.MODE_PRIVATE)
        store = ListStore(prefs, FAV)

        // TV en línea gratis (listas públicas iptv-org)
        sources[DEFAULT] = "$base/languages/spa.m3u"
        // Un chip por país de habla hispana (más España y EE. UU.)
        for (cc in listOf("ve", "ec", "pe", "co", "mx", "ar", "cl", "bo", "py", "uy",
            "cr", "pa", "gt", "hn", "ni", "sv", "do", "cu", "pr", "es", "us")) {
            val label = Info.flag(cc) + " " + Info.countryName(cc)
            sources[label] = "$base/countries/$cc.m3u"
            countryLabels.add(label)
        }
        // Películas y series gratis y legales (Internet Archive, dominio público)
        sources["🎬 Películas clásicas"] = "ia:collection:feature_films AND mediatype:movies"
        sources["🎬 Películas en español"] = "ia:collection:feature_films AND mediatype:movies AND (language:Spanish OR language:spa)"
        sources["🎬 Ciencia ficción y terror"] = "ia:collection:SciFi_Horror AND mediatype:movies"
        sources["🎬 Cine mudo"] = "ia:collection:silent_films AND mediatype:movies"
        sources["📺 TV clásica"] = "ia:collection:classic_tv AND mediatype:movies"
        for (k in sources.keys) if (k.startsWith("🎬") || k.startsWith("📺")) movieLabels.add(k)
        prefs.getString("custom", null)?.let { sources["Mi lista M3U"] = it }

        dropdowns = findViewById(R.id.dropdowns)
        search = findViewById(R.id.search)
        progress = findViewById(R.id.progress)
        empty = findViewById(R.id.empty)
        countText = findViewById(R.id.count)
        chipOk = findViewById(R.id.chipOk)
        chipOk.isChecked = onlyOk
        chipOk.setOnCheckedChangeListener { _, checked ->
            onlyOk = checked
            applyFilter()
        }

        adapter = ChannelAdapter(
            onClick = { open(it) },
            onFav = { toggleFav(it) },
            onMenu = { showListsDialog(it) },
            isFav = { store.contains(FAV, it) }
        )
        findViewById<RecyclerView>(R.id.recycler).apply {
            layoutManager = if (Tv.isTv(this@MainActivity)) GridLayoutManager(this@MainActivity, 2)
                            else LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { applyFilter() }
        })
        findViewById<View>(R.id.btnMenu).setOnClickListener { showMenu(it) }
        chipLists = addDropdown { showSourceMenu(it, listEntries) }
        chipCountry = addDropdown { showSourceMenu(it, countryLabels.toList()) }
        chipMovies = addDropdown { showSourceMenu(it, movieLabels.toList()) }
        chipCats = addDropdown { showCategories(it) }
        setupSources(null)
    }

    // ---------- Menús desplegables: canales, país, películas y categorías ----------

    private fun addDropdown(onClick: (View) -> Unit): Chip {
        val chip = layoutInflater.inflate(R.layout.chip_filter, dropdowns, false) as Chip
        chip.id = View.generateViewId()
        chip.isCheckable = true // solo para mostrar si el menú tiene algo elegido
        chip.setOnClickListener {
            refreshDropdowns() // deshace el cambio automático de marca
            onClick(it)
        }
        dropdowns.addView(chip)
        return chip
    }

    private fun setDropdown(chip: Chip, title: String, active: Boolean, value: String) {
        chip.text = (if (active) value else title) + " ▾"
        chip.isChecked = active
    }

    private fun refreshDropdowns() {
        setDropdown(chipLists, "📺 Canales", currentLabel in listEntries, currentLabel)
        setDropdown(chipCountry, "🌎 País", currentLabel in countryLabels, currentLabel)
        setDropdown(chipMovies, "🎬 Películas", currentLabel in movieLabels, currentLabel)
        val n = selectedCats.size
        chipCats.text = (if (n > 0) "🏷 Categorías ($n)" else "🏷 Categorías") + " ▾"
        chipCats.isChecked = n > 0
    }

    /** Menú desplegable de una sola opción (canales, país o películas). */
    private fun showSourceMenu(anchor: View, entries: List<String>) {
        if (entries.isEmpty()) return
        PopupMenu(this, anchor).apply {
            entries.forEachIndexed { i, label ->
                menu.add(0, i, i, (if (label == currentLabel) "● " else "") + label)
            }
            setOnMenuItemClickListener { item ->
                selectSource(entries[item.itemId])
                true
            }
            show()
        }
    }

    private fun selectSource(label: String) {
        if (label != currentLabel) {
            currentLabel = label
            load(label)
        }
        refreshDropdowns()
    }

    /** Menú desplegable de categorías: se pueden marcar varias y se aplican al instante. */
    private fun showCategories(anchor: View) {
        val pad = Tv.dp(this, 8)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        val boxes = ArrayList<MaterialCheckBox>()
        var bulk = false
        val clear = TextView(this).apply {
            text = "✕ Quitar filtros"
            textSize = 14f
            alpha = 0.8f
            isFocusable = true
            isClickable = true
            setPadding(pad * 2, pad, pad * 2, pad)
        }
        clear.setOnClickListener {
            bulk = true
            selectedCats.clear()
            boxes.forEach { it.isChecked = false }
            bulk = false
            refreshDropdowns()
            applyFilter()
        }
        box.addView(clear)
        for (name in Categories.names) {
            val cb = MaterialCheckBox(this).apply {
                text = name
                textSize = 15f
                minHeight = Tv.dp(this@MainActivity, 48)
                isChecked = name in selectedCats
            }
            cb.setOnCheckedChangeListener { _, checked ->
                if (bulk) return@setOnCheckedChangeListener
                if (checked) selectedCats.add(name) else selectedCats.remove(name)
                refreshDropdowns()
                applyFilter()
            }
            boxes.add(cb)
            box.addView(cb)
        }
        val screen = resources.displayMetrics
        val w = minOf((screen.widthPixels * 0.8).toInt(), Tv.dp(this, 320))
        box.measure(
            View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val h = minOf(box.measuredHeight, (screen.heightPixels * 0.6).toInt())
        val card = MaterialCardView(this).apply {
            radius = Tv.dp(this@MainActivity, 16).toFloat()
            cardElevation = Tv.dp(this@MainActivity, 6).toFloat()
            addView(ScrollView(this@MainActivity).apply { addView(box) })
        }
        PopupWindow(card, w, h, true).apply {
            isOutsideTouchable = true
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            elevation = Tv.dp(this@MainActivity, 8).toFloat()
            showAsDropDown(anchor)
        }
    }

    private fun setupSources(select: String?) {
        listLabels.clear()
        listEntries.clear()
        for (n in store.names()) {
            val label = if (n == FAV) FAV else "📁 $n"
            listLabels[label] = n
            listEntries.add(label)
        }
        val l = ArrayList<String>(listEntries)
        for (label in sources.keys) {
            l.add(label)
            if (label !in countryLabels && label !in movieLabels) listEntries.add(label)
        }
        val wanted = select ?: currentLabel
        val target = if (wanted in l) wanted else DEFAULT
        if (target != currentLabel) {
            currentLabel = target
            load(target)
        }
        refreshDropdowns()
    }

    private fun load(label: String) {
        val id = ++requestId
        val listName = listLabels[label]
        if (listName != null) {
            progress.visibility = View.GONE
            all = store.get(listName)
            applyFilter()
            return
        }
        val url = sources[label] ?: return
        val defaultLang = if (label == DEFAULT) "Español" else ""
        progress.visibility = View.VISIBLE
        Thread {
            try {
                val list = if (url.startsWith("ia:")) Net.searchArchive(url.removePrefix("ia:"))
                           else M3uParser.parse(Net.httpGet(url), defaultLang)
                runOnUiThread {
                    if (id != requestId) return@runOnUiThread
                    progress.visibility = View.GONE
                    all = list
                    applyFilter()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (id != requestId) return@runOnUiThread
                    progress.visibility = View.GONE
                    all = emptyList()
                    applyFilter()
                    Toast.makeText(this, "No se pudo cargar la lista", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun isOk(ch: Channel) = ch.url.startsWith("ia://") || StatusChecker.status(ch.url) == 1

    private fun applyFilter() {
        val q = search.text.toString().trim().lowercase()
        var list = Categories.apply(all, selectedCats)
        if (q.isNotEmpty()) {
            list = list.filter {
                it.name.lowercase().contains(q) || it.group.lowercase().contains(q) ||
                    Info.countryName(it.country).lowercase().contains(q) || it.lang.lowercase().contains(q)
            }
        }
        var pending = 0
        if (onlyOk) {
            // Se comprueban en segundo plano solo los canales que se están mostrando
            // (las películas de Internet Archive se verifican al reproducirlas).
            for (ch in list) {
                if (!ch.url.startsWith("ia://")) StatusChecker.request(ch) { runOnUiThread { scheduleRefresh() } }
            }
            pending = list.count { !it.url.startsWith("ia://") && StatusChecker.status(it.url) <= 0 }
            list = list.filter { isOk(it) }
        }
        adapter.submit(list)
        countText.text = if (onlyOk) {
            "${list.size} funcionan" + (if (pending > 0) " · verificando $pending…" else "")
        } else {
            "${list.size} resultados"
        }
        empty.text = when {
            onlyOk && pending > 0 -> "Verificando canales… irán apareciendo los que funcionan"
            selectedCats.isNotEmpty() -> "Ningún canal coincide con las categorías elegidas"
            else -> "Nada por aquí todavía"
        }
        empty.visibility = if (list.isEmpty() && progress.visibility != View.VISIBLE) View.VISIBLE else View.GONE
    }

    private fun scheduleRefresh() {
        if (refreshPending) return
        refreshPending = true
        ui.postDelayed({
            refreshPending = false
            applyFilter()
        }, 700)
    }

    private fun refreshView() {
        val ln = listLabels[currentLabel]
        if (ln != null) {
            all = store.get(ln)
            applyFilter()
        } else {
            adapter.notifyDataSetChanged()
        }
    }

    // ---------- Favoritos y listas personalizadas ----------

    private fun toggleFav(ch: Channel) {
        val msg: String
        if (store.contains(FAV, ch)) {
            store.remove(FAV, ch); msg = "Quitado de $FAV"
        } else {
            store.add(FAV, ch); msg = "Agregado a $FAV"
        }
        store.save()
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        refreshView()
    }

    private fun showListsDialog(ch: Channel) {
        val names = store.names().toTypedArray()
        val checked = BooleanArray(names.size) { store.contains(names[it], ch) }
        fun applyChecks() {
            names.forEachIndexed { i, n -> if (checked[i]) store.add(n, ch) else store.remove(n, ch) }
            store.save()
            refreshView()
        }
        AlertDialog.Builder(this)
            .setTitle(ch.name)
            .setMultiChoiceItems(names, checked) { _, i, c -> checked[i] = c }
            .setPositiveButton("Guardar") { _, _ -> applyChecks() }
            .setNeutralButton("Nueva lista") { _, _ ->
                applyChecks()
                askNewList { showListsDialog(ch) }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun askNewList(onDone: (String) -> Unit) {
        val input = EditText(this).apply { hint = "Nombre de la lista" }
        AlertDialog.Builder(this)
            .setTitle("Nueva lista")
            .setView(input)
            .setPositiveButton("Crear") { _, _ ->
                val n = input.text.toString().trim()
                if (n.isEmpty() || store.names().contains(n) || n == FAV) {
                    Toast.makeText(this, "Nombre no válido o ya existe", Toast.LENGTH_SHORT).show()
                } else {
                    store.create(n)
                    store.save()
                    setupSources(null)
                    onDone(n)
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showMenu(anchor: View) {
        PopupMenu(this, anchor).apply {
            menu.add(0, 1, 0, "Nueva lista")
            menu.add(0, 2, 1, "Eliminar lista actual")
            menu.add(0, 3, 2, "Agregar lista M3U (URL)")
            setOnMenuItemClickListener {
                when (it.itemId) {
                    1 -> askNewList { n -> setupSources("📁 $n") }
                    2 -> deleteCurrentList()
                    3 -> askCustom()
                }
                true
            }
            show()
        }
    }

    private fun deleteCurrentList() {
        val ln = listLabels[currentLabel]
        if (ln == null || ln == FAV) {
            Toast.makeText(this, "Elige primero una de tus listas (📁)", Toast.LENGTH_LONG).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Eliminar \"$ln\"")
            .setMessage("Se borrará la lista y su contenido guardado.")
            .setPositiveButton("Eliminar") { _, _ ->
                store.delete(ln)
                store.save()
                setupSources(FAV)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun askCustom() {
        val input = EditText(this).apply {
            hint = "https://...lista.m3u"
            setText(prefs.getString("custom", ""))
        }
        AlertDialog.Builder(this)
            .setTitle("URL de lista M3U")
            .setView(input)
            .setPositiveButton("Guardar") { _, _ ->
                val u = input.text.toString().trim()
                if (u.startsWith("http")) {
                    prefs.edit().putString("custom", u).apply()
                    sources["Mi lista M3U"] = u
                    currentLabel = ""
                    setupSources("Mi lista M3U")
                } else {
                    Toast.makeText(this, "URL no válida", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ---------- Reproducción ----------

    private fun open(ch: Channel) {
        val list = adapter.current()
        Zap.items = list
        Zap.index = list.indexOfFirst { it.url == ch.url }.coerceAtLeast(0)
        Zap.label = currentLabel
        startActivity(Intent(this, PlayerActivity::class.java))
    }

    // ---------- Adaptador: miniatura, país, idioma y estado ----------

    class ChannelAdapter(
        private val onClick: (Channel) -> Unit,
        private val onFav: (Channel) -> Unit,
        private val onMenu: (Channel) -> Unit,
        private val isFav: (Channel) -> Boolean
    ) : RecyclerView.Adapter<ChannelAdapter.VH>() {
        private var items: List<Channel> = emptyList()
        private val main = Handler(Looper.getMainLooper())

        fun submit(list: List<Channel>) { items = list; notifyDataSetChanged() }

        fun current(): List<Channel> = items

        class VH(v: View) : RecyclerView.ViewHolder(v) {
            val thumb: ImageView = v.findViewById(R.id.thumb)
            val name: TextView = v.findViewById(R.id.name)
            val info: TextView = v.findViewById(R.id.info)
            val group: TextView = v.findViewById(R.id.group)
            val status: TextView = v.findViewById(R.id.status)
            val star: TextView = v.findViewById(R.id.star)
            val menu: TextView = v.findViewById(R.id.menu)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(LayoutInflater.from(parent.context).inflate(R.layout.item_channel, parent, false))

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: VH, position: Int) {
            val ch = items[position]
            h.name.text = ch.name
            h.group.text = ch.group

            val parts = ArrayList<String>()
            if (ch.country.isNotEmpty()) {
                parts.add((Info.flag(ch.country) + " " + Info.countryName(ch.country)).trim())
            }
            if (ch.lang.isNotEmpty()) parts.add(ch.lang)
            h.info.text = parts.joinToString(" · ")
            h.info.visibility = if (parts.isEmpty()) View.GONE else View.VISIBLE

            if (ch.logo.isEmpty()) {
                Glide.with(h.thumb).clear(h.thumb)
                h.thumb.setImageResource(R.drawable.ic_placeholder)
            } else {
                Glide.with(h.thumb).load(ch.logo)
                    .placeholder(R.drawable.ic_placeholder)
                    .error(R.drawable.ic_placeholder)
                    .into(h.thumb)
            }

            bindStatus(h, ch)
            h.star.text = if (isFav(ch)) "★" else "☆"
            h.star.setOnClickListener { onFav(ch) }
            h.menu.setOnClickListener { onMenu(ch) }
            h.itemView.setOnClickListener { onClick(ch) }
            h.itemView.setOnLongClickListener { onMenu(ch); true }
            (h.itemView as? MaterialCardView)?.let { card ->
                val w = (3 * card.resources.displayMetrics.density).toInt()
                card.strokeColor = 0xFFFFC107.toInt()
                card.strokeWidth = if (card.hasFocus()) w else 0
                card.setOnFocusChangeListener { _, focused -> card.strokeWidth = if (focused) w else 0 }
            }
        }

        override fun onBindViewHolder(h: VH, position: Int, payloads: MutableList<Any>) {
            if (payloads.isNotEmpty()) bindStatus(h, items[position])
            else super.onBindViewHolder(h, position, payloads)
        }

        private fun bindStatus(h: VH, ch: Channel) {
            var st = StatusChecker.status(ch.url)
            if (st == -1) {
                StatusChecker.request(ch) { notifyUrl(ch.url) }
                st = 0
            }
            when (st) {
                1 -> { h.status.text = "✓"; h.status.setBackgroundResource(R.drawable.bg_ok) }
                2 -> { h.status.text = "✕"; h.status.setBackgroundResource(R.drawable.bg_fail) }
                else -> { h.status.text = "…"; h.status.setBackgroundResource(R.drawable.bg_wait) }
            }
        }

        private fun notifyUrl(url: String) {
            main.post {
                val i = items.indexOfFirst { it.url == url }
                if (i >= 0) notifyItemChanged(i, "status")
            }
        }
    }
}
