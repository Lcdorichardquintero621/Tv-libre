package com.tvlibre.app

import android.app.Activity
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.google.android.material.bottomsheet.BottomSheetDialog
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Programación del día de un canal. Baja un archivo pequeño solo cuando se toca el botón 🗓.
 * Los archivos los genera la tarea "Guia" de GitHub y quedan en la rama epg-data.
 */
object Guide {
    // Repositorio de GitHub donde la tarea "Guia" publica los archivos.
    const val BASE = "https://raw.githubusercontent.com/lcdorichardquintero621/Tv-libre/epg-data/"

    class Program(val start: Long, val end: Long, val title: String)

    /** Lista vacía = el canal no tiene programación. Lanza excepción si no se pudo cargar. */
    fun load(ch: Channel): List<Program> {
        if (ch.tvgId.isBlank()) return emptyList()
        val file = ch.tvgId.replace(Regex("[^A-Za-z0-9._-]"), "_") + ".json"
        val c = URL(BASE + file).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        try {
            if (c.responseCode == 404) return emptyList()
            if (c.responseCode !in 200..299) throw java.io.IOException("HTTP " + c.responseCode)
            val text = c.inputStream.bufferedReader().use { it.readText() }
            val arr = JSONObject(text).optJSONArray("p") ?: return emptyList()
            val out = ArrayList<Program>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Program(o.getLong("s"), o.getLong("e"), o.optString("t")))
            }
            return out.sortedBy { it.start }
        } finally {
            c.disconnect()
        }
    }

    fun show(act: Activity, ch: Channel) {
        val dlg = BottomSheetDialog(act)
        val pad = Tv.dp(act, 20)
        val col = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        col.addView(TextView(act).apply {
            text = "🗓 " + ch.name
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
        })
        val body = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, Tv.dp(act, 10), 0, 0)
        }
        fun msg(t: String) {
            body.removeAllViews()
            body.addView(TextView(act).apply {
                text = t
                textSize = 15f
                alpha = 0.85f
                gravity = Gravity.CENTER
                setPadding(0, Tv.dp(act, 24), 0, Tv.dp(act, 24))
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        msg("Cargando programación…")
        val scroll = ScrollView(act).apply { addView(body) }
        col.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        dlg.setContentView(col)
        dlg.show()

        Thread {
            val res: List<Program>? = try { load(ch) } catch (e: Exception) { null }
            act.runOnUiThread {
                if (!dlg.isShowing) return@runOnUiThread
                if (res == null) { msg("No se pudo cargar la programación. Revisa tu conexión."); return@runOnUiThread }
                val now = System.currentTimeMillis()
                val cal = Calendar.getInstance()
                cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0)
                cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
                val dayStart = cal.timeInMillis
                val dayEnd = dayStart + 24L * 3600 * 1000
                val today = res.filter { it.end > dayStart && it.start < dayEnd && it.end > now - 3600_000L }
                if (today.isEmpty()) { msg("Este canal no cuenta con programación en este momento."); return@runOnUiThread }
                val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
                body.removeAllViews()
                for (p in today) {
                    val live = now in p.start until p.end
                    body.addView(TextView(act).apply {
                        text = (if (live) "▶ " else "   ") + fmt.format(Date(p.start)) + "   " + p.title +
                            (if (live) "   (ahora)" else "")
                        textSize = 15f
                        setPadding(0, Tv.dp(act, 7), 0, Tv.dp(act, 7))
                        if (live) setTypeface(typeface, Typeface.BOLD)
                        else if (p.end <= now) alpha = 0.5f
                    })
                }
            }
        }.start()
    }
}
