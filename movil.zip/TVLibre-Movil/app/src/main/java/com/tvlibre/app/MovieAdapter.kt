package com.tvlibre.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.material.card.MaterialCardView

/** Tarjetas con carátula en cuadrícula: la presentación de las películas. */
class MovieAdapter(
    private val onClick: (Channel) -> Unit,
    private val onFav: (Channel) -> Unit,
    private val onMenu: (Channel) -> Unit,
    private val isFav: (Channel) -> Boolean
) : RecyclerView.Adapter<MovieAdapter.VH>() {
    private var items: List<Channel> = emptyList()

    fun submit(list: List<Channel>) { items = list; notifyDataSetChanged() }

    fun current(): List<Channel> = items

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val thumb: ImageView = v.findViewById(R.id.thumb)
        val name: TextView = v.findViewById(R.id.name)
        val info: TextView = v.findViewById(R.id.info)
        val star: TextView = v.findViewById(R.id.star)
        val menu: TextView = v.findViewById(R.id.menu)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_movie, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val ch = items[position]
        h.name.text = ch.name
        h.info.text = listOf(ch.group, ch.lang).filter { it.isNotEmpty() }.joinToString(" · ")
        if (ch.logo.isEmpty()) {
            Glide.with(h.thumb).clear(h.thumb)
            h.thumb.setImageResource(R.drawable.ic_placeholder)
        } else {
            Glide.with(h.thumb).load(ch.logo)
                .placeholder(R.drawable.ic_placeholder)
                .error(R.drawable.ic_placeholder)
                .into(h.thumb)
        }
        h.star.text = if (isFav(ch)) "★" else "☆"
        h.star.setOnClickListener { onFav(ch) }
        h.menu.setOnClickListener { onMenu(ch) }
        h.itemView.setOnClickListener { onClick(ch) }
        h.itemView.setOnLongClickListener { onMenu(ch); true }
        (h.itemView as? MaterialCardView)?.let { card ->
            val w = (3 * card.resources.displayMetrics.density).toInt()
            card.strokeColor = 0xFFFFC107.toInt()
            card.strokeWidth = if (card.hasFocus()) w else 0
            card.setOnFocusChangeListener { _, focused -> card.strokeWidth = if (focused) w else 0 }
        }
    }
}
