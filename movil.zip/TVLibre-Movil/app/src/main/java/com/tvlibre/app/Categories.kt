package com.tvlibre.app

import java.text.Normalizer

/**
 * Categorías para filtrar canales desde la búsqueda.
 * Las listas M3U no traen todas estas categorías, así que se deducen del grupo
 * (group-title de iptv-org), del nombre del canal y del idioma.
 *
 * Reglas:
 *  - "Español" es una condición de idioma: se suma (Y) a las demás.
 *  - Las demás categorías se combinan con O: aparece el canal si cumple cualquiera.
 *  - "Adulto" está oculto siempre, salvo que se marque.
 */
object Categories {
    const val SPANISH = "Español"
    const val ADULT = "Adulto"

    private class Cat(group: String, name: String, val archive: Boolean = false) {
        val g = Regex("\\b(?:$group)\\b")
        val n = Regex(name)
    }

    // Textos ya sin tildes ni mayúsculas (ver clean)
    private val defs = linkedMapOf(
        "Película" to Cat(
            "movies?|films?|peliculas?",
            "peliculas?|movies?|\\bfilms?\\b",
            archive = true
        ),
        "Infantil" to Cat(
            "kids|children|family|animation|infantil|ninos",
            "\\bkids?\\b|infantil|ninos|junior|cartoon|disney|nickelodeon|\\bnick\\b|baby|\\btoons?\\b|peques?|cbeebies|dibujos|\\bboing\\b|\\bclan\\b"
        ),
        "Documentales" to Cat(
            "documentary|documental(?:es)?",
            "documental|documentary|discovery|national geographic|nat geo|history|investigation"
        ),
        "Animales" to Cat(
            "animals?|animales|wildlife|nature|pets",
            "animal|wildlife|nature|naturaleza|fauna|\\bzoo\\b|\\bpets?\\b|mascotas?|safari|ocean|marine|salvaje|\\bdogs?\\b|\\bperros?\\b|\\bgatos?\\b|aquarium|acuario"
        ),
        "Noticias" to Cat(
            "news|noticias|weather|legislative",
            "noticias?|news|noticiero|noticiario|informativ|24 ?horas|24h|\\bcnn\\b|telesur|ntn24|euronews|jazeera|france 24|\\bdw\\b|\\brpp\\b|canal n\\b"
        ),
        "Deporte" to Cat(
            "sports?|deportes?",
            "deportes?|sports?|futbol|football|soccer|espn|dazn|\\btyc\\b|win sports|\\bgol\\b|\\bnba\\b|\\bnfl\\b|\\bufc\\b|tenis|tennis|golf|boxeo|olimp|\\bliga\\b|bein|tudn|\\bwwe\\b|ciclismo|rugby|baloncesto|basket|beisbol|baseball"
        ),
        "Entretenimiento y variedad" to Cat(
            "entertainment|general|comedy|lifestyle|interactive|shop|variety|variedad|entretenimiento|reality|cooking|relax|auto|outdoor|public",
            "entretenimiento|variedad(?:es)?|\\bshow\\b|reality|comedia|humor|cocina|lifestyle|\\bgeneral\\b"
        ),
        "Series" to Cat(
            "series?",
            "series?|telenovelas?|novelas?|sitcom|\\bdramas?\\b"
        ),
        "Cine" to Cat(
            "cinema|cine|classic",
            "\\bcine\\b|cinema|cinecanal|cinemax|western|terror|horror|thriller|sci-?fi|ciencia ficcion|silent|cine mudo",
            archive = true
        ),
        "Música" to Cat(
            "music|musica",
            "music|musica|radio|\\bmtv\\b|vevo|reggaeton|salsa|\\brock\\b|\\bpop\\b|cumbia|\\btrace\\b|\\bfm\\b|telehit|stingray|concert|karaoke|jazz|\\bhits?\\b|\\bhtv\\b"
        ),
        "Animes" to Cat(
            "anime|manga",
            "anime|manga|crunchyroll|animax|toonami|ani-?one|naruto|dragon ball|one piece|pokemon|otaku"
        ),
        "Cultura y educativo" to Cat(
            "culture|education|educational|science|educacion|cultura|ciencia",
            "cultura|cultural|educati|educacion|universidad|university|ciencia|science|aprende|learn|\\barte\\b|museo|encuentro|escola|escuela|biblioteca|\\bunam\\b|\\bpbs\\b"
        ),
        ADULT to Cat(
            "xxx|adult(?! swim)|adulto|erotic|erotico",
            "xxx|adult(?! swim)|adulto|erotic|sexy|playboy|porn|hustler|penthouse|brazzers|sensual|18\\+"
        )
    )

    private val adultCat = defs.getValue(ADULT)

    /** Nombres en el orden en que se muestran en el menú. */
    val names: List<String> = listOf(SPANISH) + defs.keys

    private class Norm(val name: String, val group: String)

    private val marks = Regex("\\p{M}+")
    private val cache = HashMap<String, Norm>() // solo se usa desde el hilo principal

    private fun clean(s: String) =
        Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(marks, "")

    private fun norm(ch: Channel): Norm =
        cache.getOrPut(ch.url) { Norm(clean(ch.name), clean(ch.group)) }

    private fun matches(cat: Cat, ch: Channel): Boolean {
        if (cat.archive && ch.url.startsWith("ia://")) return true
        val n = norm(ch)
        return cat.g.containsMatchIn(n.group) || cat.n.containsMatchIn(n.name)
    }

    /** Aplica las categorías elegidas (vacío = todas, sin adultos). */
    fun apply(list: List<Channel>, selected: Set<String>): List<Channel> {
        val adultWanted = ADULT in selected
        val spanish = SPANISH in selected
        val cats = selected.mapNotNull { defs[it] }
        return list.filter { ch ->
            when {
                !adultWanted && matches(adultCat, ch) -> false
                spanish && !ch.lang.equals(SPANISH, ignoreCase = true) -> false
                cats.isEmpty() -> true
                else -> cats.any { matches(it, ch) }
            }
        }
    }
}
