package com.tvlibre.app

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/** Guarda Favoritos y las listas personalizadas del usuario en el teléfono. */
class ListStore(private val prefs: SharedPreferences, private val fav: String) {
    private val lists = LinkedHashMap<String, MutableList<Channel>>()

    init {
        try {
            val o = JSONObject(prefs.getString("lists", "{}") ?: "{}")
            for (k in o.keys()) {
                val arr = o.getJSONArray(k)
                val l = ArrayList<Channel>()
                for (i in 0 until arr.length()) {
                    val c = arr.getJSONObject(i)
                    l.add(Channel(c.optString("n"), c.optString("g"), c.optString("u"), c.optString("l"), c.optString("c"), c.optString("lg")))
                }
                lists[k] = l
            }
        } catch (e: Exception) {
            lists.clear()
        }
        val tmp = LinkedHashMap(lists)
        lists.clear()
        lists[fav] = tmp.remove(fav) ?: ArrayList()
        lists.putAll(tmp)
    }

    fun names(): List<String> = lists.keys.toList()
    fun get(name: String): List<Channel> = (lists[name] ?: emptyList<Channel>()).toList()
    fun contains(name: String, ch: Channel) = lists[name]?.any { it.url == ch.url } == true

    fun add(name: String, ch: Channel) {
        val l = lists[name] ?: return
        if (l.none { it.url == ch.url }) l.add(ch)
    }

    fun remove(name: String, ch: Channel) {
        lists[name]?.removeAll { it.url == ch.url }
    }

    fun create(name: String) {
        if (!lists.containsKey(name)) lists[name] = ArrayList()
    }

    fun delete(name: String) {
        if (name != fav) lists.remove(name)
    }

    fun save() {
        val o = JSONObject()
        for ((k, v) in lists) {
            val arr = JSONArray()
            for (c in v) {
                arr.put(JSONObject().put("n", c.name).put("g", c.group).put("u", c.url).put("l", c.logo).put("c", c.country).put("lg", c.lang))
            }
            o.put(k, arr)
        }
        prefs.edit().putString("lists", o.toString()).apply()
    }
}
