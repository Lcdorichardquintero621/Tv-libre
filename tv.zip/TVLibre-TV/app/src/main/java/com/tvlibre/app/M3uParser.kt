package com.tvlibre.app

data class Channel(
    val name: String,
    val group: String,
    val url: String,
    val logo: String = "",
    val country: String = "",
    val lang: String = ""
)

object M3uParser {
    private val groupRe = Regex("group-title=\"([^\"]*)\"")
    private val logoRe = Regex("tvg-logo=\"([^\"]*)\"")
    private val idRe = Regex("tvg-id=\"([^\"]*)\"")
    private val ctryRe = Regex("tvg-country=\"([^\"]*)\"")
    private val langRe = Regex("tvg-language=\"([^\"]*)\"")
    private val idCountryRe = Regex("\\.([A-Za-z]{2})(@.*)?$")

    fun parse(text: String, defaultLang: String = ""): List<Channel> {
        val out = ArrayList<Channel>()
        var name: String? = null
        var group = ""
        var logo = ""
        var cc = ""
        var lang = ""
        for (raw in text.lineSequence()) {
            val line = raw.trim()
            if (line.startsWith("#EXTINF")) {
                name = line.substringAfterLast(",").trim()
                group = groupRe.find(line)?.groupValues?.get(1)?.trim().orEmpty()
                logo = logoRe.find(line)?.groupValues?.get(1)?.trim().orEmpty()
                val id = idRe.find(line)?.groupValues?.get(1).orEmpty()
                cc = idCountryRe.find(id)?.groupValues?.get(1)?.lowercase().orEmpty()
                if (cc.isEmpty()) {
                    val t = ctryRe.find(line)?.groupValues?.get(1)?.trim().orEmpty()
                    if (t.length >= 2 && t.substring(0, 2).all { it.isLetter() }) cc = t.substring(0, 2).lowercase()
                }
                val l = langRe.find(line)?.groupValues?.get(1)?.trim().orEmpty()
                lang = if (l.isNotEmpty()) Info.langName(l)
                       else if (defaultLang.isNotEmpty()) defaultLang
                       else Info.mainLanguageOf(cc)
            } else if (line.isNotEmpty() && !line.startsWith("#") && name != null) {
                if (line.startsWith("http")) {
                    out.add(Channel(name.ifEmpty { "Sin nombre" }, group.ifEmpty { "General" }, line, logo, cc, lang))
                }
                name = null
                group = ""
                logo = ""
                cc = ""
                lang = ""
            }
        }
        return out
    }
}
