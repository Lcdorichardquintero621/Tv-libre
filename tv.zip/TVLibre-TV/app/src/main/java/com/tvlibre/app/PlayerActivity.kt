package com.tvlibre.app

import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.cast.CastPlayer
import androidx.media3.cast.SessionAvailabilityListener
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.mediarouter.app.MediaRouteButton
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.gms.cast.framework.CastButtonFactory
import com.google.android.gms.cast.framework.CastContext

/** Lista que se está viendo (por ejemplo Venezuela) para pasar de canal en canal. */
object Zap {
    var items: List<Channel> = emptyList()
    var index = 0
    var label = ""
}

fun infoLine(ch: Channel): String {
    val parts = ArrayList<String>()
    if (ch.country.isNotEmpty()) parts.add((Info.flag(ch.country) + " " + Info.countryName(ch.country)).trim())
    if (ch.lang.isNotEmpty()) parts.add(ch.lang)
    if (ch.group.isNotEmpty()) parts.add(ch.group)
    return parts.joinToString(" · ")
}

class PlayerActivity : AppCompatActivity() {
    private var localPlayer: ExoPlayer? = null
    private var castPlayer: CastPlayer? = null
    private var player: Player? = null          // el que está activo (teléfono o TV)
    private lateinit var view: PlayerView
    private lateinit var container: FrameLayout
    private lateinit var list: RecyclerView
    private lateinit var header: TextView
    private lateinit var titleView: TextView
    private lateinit var fsBtn: ImageButton
    private lateinit var timeRow: View
    private lateinit var adapter: ZapAdapter
    private val handler = Handler(Looper.getMainLooper())

    private var items: List<Channel> = emptyList()
    private var index = 0
    private var fullscreen = false
    private var loadId = 0
    private var curUrl = ""
    private var curName = ""
    private val isTv by lazy { Tv.isTv(this) }
    private lateinit var zapBanner: TextView
    private val hideBanner = Runnable { zapBanner.visibility = View.GONE }

    private var zapping = false   // true cuando se cambia con ▲▼, CH+/CH- o ⏮ ⏭
    private var lastDir = 1
    private var autoSkips = 0

    private val listener = object : Player.Listener {
        override fun onPlayerError(error: PlaybackException) {
            val isMovie = items[index].url.startsWith("ia://")
            if (!isMovie) {
                StatusChecker.mark(items[index].url, false)
                adapter.notifyStatus(index)
            }
            if (zapping && !isMovie && autoSkips < 6 && items.size > 1) {
                autoSkips++
                Toast.makeText(this@PlayerActivity, "Canal caído, probando el siguiente…", Toast.LENGTH_SHORT).show()
                step(lastDir)
            } else {
                Toast.makeText(
                    this@PlayerActivity,
                    "No se pudo reproducir este canal (puede estar caído o bloqueado)",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
        override fun onPlaybackStateChanged(playbackState: Int) {
            updateTimeRow()
            if (playbackState == Player.STATE_READY) {
                autoSkips = 0
                if (!items[index].url.startsWith("ia://")) {
                    StatusChecker.mark(items[index].url, true)
                    adapter.notifyStatus(index)
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        items = Zap.items
        if (items.isEmpty()) { finish(); return }
        index = Zap.index.coerceIn(0, items.size - 1)

        setContentView(R.layout.activity_player)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        view = findViewById(R.id.playerView)
        container = findViewById(R.id.playerContainer)
        list = findViewById(R.id.zapList)
        header = findViewById(R.id.listHeader)
        titleView = view.findViewById(R.id.player_title)
        fsBtn = view.findViewById(R.id.btn_fullscreen)
        timeRow = view.findViewById(R.id.time_row)

        view.findViewById<View>(R.id.btn_back).setOnClickListener { onBackPressedDispatcher.onBackPressed() }
        view.findViewById<View>(R.id.btn_prev_channel).setOnClickListener { step(-1) }
        view.findViewById<View>(R.id.btn_next_channel).setOnClickListener { step(1) }
        view.findViewById<View>(R.id.btn_mirror).setOnClickListener { openMirroring() }
        view.findViewById<View>(R.id.btn_channels).setOnClickListener { openChannelList() }
        zapBanner = findViewById(R.id.zap_banner)
        fsBtn.setOnClickListener { toggleFullscreen() }

        // Botón de proyectar (Google Cast); se oculta si el teléfono no tiene Google Play Services
        val castBtn = view.findViewById<MediaRouteButton>(R.id.btn_cast)
        if (isTv) {
            // En TV no se proyecta ni se gira: solo canales y control remoto
            castBtn.visibility = View.GONE
            view.findViewById<View>(R.id.btn_mirror).visibility = View.GONE
            fsBtn.visibility = View.GONE
        } else {
            try {
                CastButtonFactory.setUpMediaRouteButton(applicationContext, castBtn)
                castBtn.setAlwaysVisible(true)
            } catch (e: Exception) {
                castBtn.visibility = View.GONE
            }
        }

        adapter = ZapAdapter(items) { zapping = false; playIndex(it) }
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter
        header.text = (if (Zap.label.isEmpty()) "Canales" else Zap.label) + " · " + items.size + " para elegir"

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (fullscreen && !isTv) toggleFullscreen() else finish()
            }
        })
        applyMode()
    }

    // ---------- Reproductores: teléfono (ExoPlayer) y TV (Cast) ----------

    private fun ensurePlayers() {
        if (localPlayer == null) localPlayer = ExoPlayer.Builder(this).build()
        if (castPlayer == null && !isTv) {
            try {
                val cp = CastPlayer(CastContext.getSharedInstance(this))
                cp.setSessionAvailabilityListener(object : SessionAvailabilityListener {
                    override fun onCastSessionAvailable() { switchTo(cp) }
                    override fun onCastSessionUnavailable() { switchTo(localPlayer) }
                })
                castPlayer = cp
            } catch (e: Exception) {
                castPlayer = null
            }
        }
    }

    /** Pasa la reproducción al teléfono o a la TV sin perder el canal actual. */
    private fun switchTo(next: Player?) {
        if (next == null || next === player) return
        val old = player
        val live = old == null || old.isCurrentMediaItemLive || old.duration == C.TIME_UNSET
        val pos = if (live || old == null) C.TIME_UNSET else old.currentPosition
        val wasPlaying = old?.playWhenReady ?: true
        old?.removeListener(listener)
        old?.stop()
        old?.clearMediaItems()
        player = next
        view.player = next
        next.addListener(listener)
        if (curUrl.isNotEmpty()) {
            next.setMediaItem(buildItem(curUrl, curName, next is CastPlayer), pos)
            next.prepare()
            next.playWhenReady = wasPlaying
        }
        updateTimeRow()
    }

    override fun onStart() {
        super.onStart()
        if (items.isEmpty()) return
        ensurePlayers()
        if (player == null) {
            val cp = castPlayer
            val p: Player = if (cp != null && cp.isCastSessionAvailable) cp else localPlayer!!
            player = p
            p.addListener(listener)
            view.player = p
            zapping = false
            playIndex(index)
        } else {
            view.player = player
        }
    }

    override fun onStop() {
        super.onStop()
        loadId++
        view.player = null
        // Si se está proyectando, la TV sigue reproduciendo aunque apagues la pantalla del teléfono
        if (player !is CastPlayer) {
            player?.removeListener(listener)
            localPlayer?.release()
            localPlayer = null
            player = null
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        castPlayer?.let { cp ->
            cp.setSessionAvailabilityListener(null)
            if (isFinishing) cp.stop()
            cp.release()
        }
        castPlayer = null
        localPlayer?.release()
        localPlayer = null
        super.onDestroy()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        applyMode()
    }

    // ---------- Cambiar de canal ----------

    /** Pasa al canal siguiente o anterior, saltando los que ya se sabe que están caídos. */
    private fun step(d: Int) {
        if (items.isEmpty()) return
        lastDir = d
        zapping = true
        var target = -1
        var i = index
        for (n in 1..items.size) {
            i = (i + d + items.size) % items.size
            if (StatusChecker.status(items[i].url) != 2) { target = i; break }
        }
        if (target == -1) {
            Toast.makeText(this, "No hay canales disponibles en esta lista", Toast.LENGTH_LONG).show()
            return
        }
        playIndex(target)
        prefetch(target, d)
    }

    /** Verifica por adelantado los próximos canales para poder saltar los caídos. */
    private fun prefetch(from: Int, d: Int) {
        val n = items.size
        for (k in 1..8) {
            val i = (((from + d * k) % n) + n) % n
            StatusChecker.request(items[i]) { handler.post { adapter.notifyStatus(i) } }
        }
    }

    private fun playIndex(i: Int) {
        index = i
        Zap.index = i
        val ch = items[i]
        titleView.text = ch.name
        showBanner("${i + 1}/${items.size} · ${ch.name}")
        adapter.setCurrent(i)
        list.smoothScrollToPosition(i)
        val id = ++loadId
        if (ch.url.startsWith("ia://")) {
            Toast.makeText(this, "Preparando película…", Toast.LENGTH_SHORT).show()
            Thread {
                val real = try { Net.resolveArchive(ch.url.removePrefix("ia://")) } catch (e: Exception) { null }
                runOnUiThread {
                    if (id != loadId) return@runOnUiThread
                    if (real == null) {
                        Toast.makeText(this, "No se encontró un video reproducible", Toast.LENGTH_LONG).show()
                    } else {
                        start(real)
                    }
                }
            }.start()
        } else {
            start(ch.url)
        }
    }

    private fun buildItem(url: String, name: String, forCast: Boolean): MediaItem {
        val u = url.lowercase()
        val mime: String? = when {
            u.contains("m3u8") -> MimeTypes.APPLICATION_M3U8
            u.contains(".mp4") -> MimeTypes.VIDEO_MP4
            forCast -> MimeTypes.APPLICATION_M3U8
            else -> null
        }
        return MediaItem.Builder()
            .setUri(url)
            .setMediaMetadata(MediaMetadata.Builder().setTitle(name).build())
            .apply { if (mime != null) setMimeType(mime) }
            .build()
    }

    private fun start(url: String) {
        val p = player ?: return
        curUrl = url
        curName = items[index].name
        p.setMediaItem(buildItem(url, curName, p is CastPlayer))
        p.prepare()
        p.playWhenReady = true
        view.showController()
    }

    private fun updateTimeRow() {
        val p = player ?: return
        val live = p.isCurrentMediaItemLive || p.duration == C.TIME_UNSET
        timeRow.visibility = if (live) View.INVISIBLE else View.VISIBLE
    }

    // ---------- Control remoto y lista de canales ----------

    private fun showBanner(text: String) {
        zapBanner.text = text
        zapBanner.visibility = View.VISIBLE
        handler.removeCallbacks(hideBanner)
        handler.postDelayed(hideBanner, 2500)
    }

    private fun openChannelList() {
        val names = Array(items.size) { i ->
            val st = StatusChecker.status(items[i].url)
            (if (st == 1) "✓  " else if (st == 2) "✕  " else "") + items[i].name
        }
        AlertDialog.Builder(this)
            .setTitle(if (Zap.label.isEmpty()) "Canales" else Zap.label)
            .setSingleChoiceItems(names, index) { d, which ->
                d.dismiss()
                zapping = false
                playIndex(which)
            }
            .setNegativeButton("Cerrar", null)
            .show()
    }

    /**
     * Control remoto: CH+/CH- o ⏮ ⏭ cambian de canal. En TV, con los controles ocultos:
     * ▲ canal anterior, ▼ canal siguiente, ◀ ▶ retroceder/adelantar (películas), OK muestra los controles.
     */
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN && items.isNotEmpty()) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_CHANNEL_UP, KeyEvent.KEYCODE_PAGE_UP, KeyEvent.KEYCODE_MEDIA_NEXT -> {
                    if (event.repeatCount == 0) step(1)
                    return true
                }
                KeyEvent.KEYCODE_CHANNEL_DOWN, KeyEvent.KEYCODE_PAGE_DOWN, KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                    if (event.repeatCount == 0) step(-1)
                    return true
                }
            }
            if (isTv && !view.isControllerFullyVisible) {
                when (event.keyCode) {
                    KeyEvent.KEYCODE_DPAD_UP -> { if (event.repeatCount == 0) step(-1); return true }
                    KeyEvent.KEYCODE_DPAD_DOWN -> { if (event.repeatCount == 0) step(1); return true }
                    KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        val p = player
                        if (p != null && !p.isCurrentMediaItemLive && p.duration != C.TIME_UNSET) {
                            if (event.keyCode == KeyEvent.KEYCODE_DPAD_LEFT) p.seekBack() else p.seekForward()
                            return true
                        }
                    }
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    // ---------- Duplicar pantalla (Smart View / Miracast / Transmitir pantalla) ----------

    private fun openMirroring() {
        try {
            startActivity(Intent(Settings.ACTION_CAST_SETTINGS))
        } catch (e: Exception) {
            Toast.makeText(
                this,
                "Abre \"Smart View\" o \"Duplicar pantalla\" desde los ajustes rápidos del teléfono",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    // ---------- Pantalla completa / girar el teléfono ----------

    private fun toggleFullscreen() {
        if (fullscreen) {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            handler.postDelayed({ requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED }, 2000)
        } else {
            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
    }

    /** Horizontal = pantalla completa (sin lista ni barras); vertical = video arriba y canales abajo. */
    private fun applyMode() {
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        fullscreen = land
        list.visibility = if (land) View.GONE else View.VISIBLE
        header.visibility = if (land) View.GONE else View.VISIBLE
        val lp = container.layoutParams
        lp.height = if (land) ViewGroup.LayoutParams.MATCH_PARENT
                    else (resources.displayMetrics.widthPixels * 9f / 16f).toInt()
        container.layoutParams = lp
        fsBtn.setImageResource(if (land) R.drawable.ic_fullscreen_exit else R.drawable.ic_fullscreen)

        val ctrl = WindowInsetsControllerCompat(window, window.decorView)
        if (land) {
            ctrl.hide(WindowInsetsCompat.Type.systemBars())
            ctrl.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } else {
            ctrl.show(WindowInsetsCompat.Type.systemBars())
        }
    }
}

/** Lista compacta de canales debajo del video. */
class ZapAdapter(
    private val items: List<Channel>,
    private val onPick: (Int) -> Unit
) : RecyclerView.Adapter<ZapAdapter.VH>() {
    private var current = -1
    private val main = Handler(Looper.getMainLooper())

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val now: TextView = v.findViewById(R.id.now)
        val thumb: ImageView = v.findViewById(R.id.thumb)
        val name: TextView = v.findViewById(R.id.name)
        val info: TextView = v.findViewById(R.id.info)
        val status: TextView = v.findViewById(R.id.status)
    }

    fun notifyStatus(i: Int) {
        if (i in 0 until items.size) notifyItemChanged(i, "status")
    }

    fun setCurrent(i: Int) {
        val old = current
        current = i
        if (old >= 0) notifyItemChanged(old, "now")
        notifyItemChanged(i, "now")
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_zap, parent, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, position: Int) {
        val ch = items[position]
        h.name.text = ch.name
        h.info.text = infoLine(ch)
        if (ch.logo.isEmpty()) {
            Glide.with(h.thumb).clear(h.thumb)
            h.thumb.setImageResource(R.drawable.ic_placeholder)
        } else {
            Glide.with(h.thumb).load(ch.logo)
                .placeholder(R.drawable.ic_placeholder)
                .error(R.drawable.ic_placeholder)
                .into(h.thumb)
        }
        bindDynamic(h, position)
        h.itemView.setOnClickListener {
            val p = h.bindingAdapterPosition
            if (p != RecyclerView.NO_POSITION) onPick(p)
        }
    }

    override fun onBindViewHolder(h: VH, position: Int, payloads: MutableList<Any>) {
        if (payloads.isNotEmpty()) bindDynamic(h, position)
        else super.onBindViewHolder(h, position, payloads)
    }

    private fun bindDynamic(h: VH, position: Int) {
        val ch = items[position]
        h.now.visibility = if (position == current) View.VISIBLE else View.INVISIBLE
        var st = StatusChecker.status(ch.url)
        if (st == -1) {
            StatusChecker.request(ch) { main.post { notifyItemChanged(position, "status") } }
            st = 0
        }
        when (st) {
            1 -> { h.status.text = "✓"; h.status.setBackgroundResource(R.drawable.bg_ok) }
            2 -> { h.status.text = "✕"; h.status.setBackgroundResource(R.drawable.bg_fail) }
            else -> { h.status.text = "…"; h.status.setBackgroundResource(R.drawable.bg_wait) }
        }
    }
}
