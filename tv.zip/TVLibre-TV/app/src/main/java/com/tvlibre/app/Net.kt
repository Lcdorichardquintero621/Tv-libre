package com.tvlibre.app

import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.LinkedBlockingDeque
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit

object Net {
    fun httpGet(u: String): String {
        val conn = URL(u).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        return conn.inputStream.bufferedReader().use { it.readText() }
    }

    fun searchArchive(q: String): List<Channel> {
        val u = "https://archive.org/advancedsearch.php?q=" + URLEncoder.encode(q, "UTF-8") +
            "&fl%5B%5D=identifier&fl%5B%5D=title&fl%5B%5D=year&fl%5B%5D=language" +
            "&sort%5B%5D=downloads+desc&rows=200&output=json"
        val docs = JSONObject(httpGet(u)).getJSONObject("response").getJSONArray("docs")
        val out = ArrayList<Channel>()
        for (i in 0 until docs.length()) {
            val d = docs.getJSONObject(i)
            val id = d.optString("identifier")
            if (id.isEmpty()) continue
            val t = d.opt("title")
            val title = (if (t is JSONArray) t.optString(0) else d.optString("title")).ifEmpty { id }
            val year = d.optString("year")
            val lg = d.opt("language")
            val lang = Info.langName(if (lg is JSONArray) lg.optString(0) else d.optString("language"))
            out.add(Channel(
                title,
                if (year.isEmpty()) "Internet Archive" else year,
                "ia://$id",
                "https://archive.org/services/img/$id",
                "",
                lang
            ))
        }
        return out
    }

    fun resolveArchive(id: String): String? {
        val files = JSONObject(httpGet("https://archive.org/metadata/" + Uri.encode(id)))
            .optJSONArray("files") ?: return null
        var fallback: String? = null
        for (i in 0 until files.length()) {
            val f = files.getJSONObject(i)
            val n = f.optString("name")
            if (!n.endsWith(".mp4", ignoreCase = true)) continue
            if (f.optString("format").contains("h.264", ignoreCase = true)) {
                return "https://archive.org/download/" + Uri.encode(id) + "/" + Uri.encode(n, "/")
            }
            if (fallback == null) fallback = n
        }
        return fallback?.let { "https://archive.org/download/" + Uri.encode(id) + "/" + Uri.encode(it, "/") }
    }

    /** Comprueba, desde este teléfono, si la fuente responde y parece reproducible. */
    fun check(ch: Channel): Boolean {
        if (ch.url.startsWith("ia://")) return resolveArchive(ch.url.removePrefix("ia://")) != null
        var u = ch.url
        for (hop in 0..4) {
            val c = URL(u).openConnection() as HttpURLConnection
            c.connectTimeout = 6000
            c.readTimeout = 6000
            c.instanceFollowRedirects = false
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13)")
            try {
                val code = c.responseCode
                if (code in 300..399) {
                    val loc = c.getHeaderField("Location") ?: return false
                    u = URL(URL(u), loc).toString()
                    continue
                }
                if (code !in 200..299) return false
                val ct = (c.contentType ?: "").lowercase()
                val playlist = u.contains("m3u8", ignoreCase = true) || ct.contains("mpegurl")
                if (!playlist) return true
                val buf = ByteArray(1024)
                val n = c.inputStream.use { it.read(buf) }
                return n > 0 && String(buf, 0, n).trimStart().startsWith("#EXTM3U")
            } finally {
                c.disconnect()
            }
        }
        return false
    }
}

/** Verifica canales en segundo plano; los últimos en aparecer en pantalla se revisan primero. */
object StatusChecker {
    private val results = ConcurrentHashMap<String, Int>() // 0 = comprobando, 1 = funciona, 2 = falla
    private val queue = object : LinkedBlockingDeque<Runnable>() {
        override fun offer(e: Runnable): Boolean = offerFirst(e)
    }
    private val pool = ThreadPoolExecutor(6, 6, 0L, TimeUnit.SECONDS, queue)

    fun status(url: String): Int = results[url] ?: -1

    fun request(ch: Channel, onDone: () -> Unit) {
        if (results.putIfAbsent(ch.url, 0) != null) return
        pool.execute {
            val ok = try { Net.check(ch) } catch (e: Exception) { false }
            results[ch.url] = if (ok) 1 else 2
            onDone()
        }
    }
}
