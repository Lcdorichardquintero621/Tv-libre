package com.tvlibre.app

import android.app.UiModeManager
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration

object Tv {
    /** Android TV, Google TV, Fire TV y TV Box. */
    fun isTv(c: Context): Boolean {
        val pm = c.packageManager
        val ui = c.getSystemService(Context.UI_MODE_SERVICE) as? UiModeManager
        return pm.hasSystemFeature(PackageManager.FEATURE_LEANBACK) ||
            pm.hasSystemFeature("amazon.hardware.fire_tv") ||
            ui?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION
    }

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()
}
