# TV Libre – TV
App para Android TV, Google TV, Fire TV y TV Box (applicationId: com.tvlibre.tv).
Proyecto independiente: no comparte código con la versión móvil.
